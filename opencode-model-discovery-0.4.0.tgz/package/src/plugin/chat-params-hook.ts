import { ModelStatusCache } from '../cache/model-status-cache'
import { ToastNotifier } from '../ui/toast-notifier'
import { findSimilarModels, retryWithBackoff, categorizeError, generateAutoFixSuggestions } from '../utils'
import { getLoadedModels } from './get-loaded-models'
import { normalizeBaseURL } from '../utils/openai-compatible-api'
import { safeAsyncOperation, isPluginHookInput, canDiscoverModels, isValidModel } from '../utils/validation'
import { getValidationConfig } from '../types/plugin-config'
import type { PluginConfig } from '../types/plugin-config'

const modelStatusCache = new ModelStatusCache()

export function createChatParamsHook(toastNotifier: ToastNotifier, pluginConfig: PluginConfig) {
  const validationConfig = getValidationConfig(pluginConfig)

  return async (input: any, output: any) => {
    if (validationConfig.enabled === false) {
      return
    }

    if (!isPluginHookInput(input)) {
      console.error("[opencode-model-discovery] Invalid chat.params input")
      return
    }

    const { sessionID, agent, model, provider } = input

    if (!isValidModel(model)) {
      console.error("[opencode-model-discovery] Invalid model object")
      return
    }

    if (!canDiscoverModels(provider)) {
      return
    }

    const baseURL = normalizeBaseURL(provider.options?.baseURL || "")

    await safeAsyncOperation(
      () => toastNotifier.progress(`Checking model ${model.id}...`, "Model Validation", 10),
      undefined,
      (error: Error) => console.warn("[opencode-model-discovery] Failed to show progress toast:", error)
    )

    const validationResult = await retryWithBackoff(
      async () => {
        const loadedModels = await getLoadedModels(baseURL)
        const isModelLoaded = loadedModels.includes(model.id)

        if (!isModelLoaded) {
          throw new Error(`Model '${model.id}' not loaded`)
        }

        return loadedModels
      },
      validationConfig.retryCount,
      validationConfig.retryDelay
    )

    if (!validationResult.success || !validationResult.result) {
      const errorCategory = categorizeError(validationResult.error || "Validation operation failed", { baseURL, modelId: model.id })
      const autoFixSuggestions = generateAutoFixSuggestions(errorCategory)

      console.warn("[opencode-model-discovery] Model validation failed", {
        sessionID,
        model: model.id,
        error: validationResult.error,
        errorType: errorCategory.type,
        severity: errorCategory.severity,
        baseURL
      })

      let availableModels: string[] = []
      try {
        availableModels = await getLoadedModels(baseURL)
      } catch (e) {
        console.warn("[opencode-model-discovery] Failed to get available models for suggestions", { error: e })
      }

      const similarModels = findSimilarModels(model.id, availableModels)

      await toastNotifier.error(
        `Model '${model.id}' not ready: ${errorCategory.message}`,
        "Model Validation Failed",
        8000
      )

      if (!output.options) {
        output.options = {}
      }
      output.options.modelValidation = {
        status: "error",
        model: model.id,
        availableModels,
        errorCategory: errorCategory.type,
        severity: errorCategory.severity,
        message: errorCategory.message,
        canRetry: errorCategory.canRetry,
        autoFixAvailable: errorCategory.autoFixAvailable,
        autoFixSuggestions,
        steps: errorCategory.type === 'not_found' ? [
          "1. Ensure your provider application is running",
          "2. Download or load the desired model",
          "3. Start the server",
          "4. Try your request again"
        ] : [
          "1. Verify the server is active",
          "2. Check the server URL and port",
          "3. Try loading the model manually",
          "4. Retry your request"
        ],
        similarModels: similarModels.map(item => ({
          model: item.model,
          similarity: Math.round(item.similarity * 100),
          reason: item.reason
        }))
      }
    } else {
      const cacheStats = modelStatusCache.getStats()
      const cacheEntry = cacheStats.entries.find(entry => entry.baseURL === baseURL)
      const cacheAge = cacheEntry ? cacheEntry.age : 0

      const loadedModels = validationResult.result || []

      await toastNotifier.success(`Model '${model.id}' is ready to use`, "Model Validated")

      if (!output.options) {
        output.options = {}
      }
      output.options.modelValidation = {
        status: "success",
        model: model.id,
        availableModels: loadedModels,
        message: `Model '${model.id}' is loaded and ready.`,
        cacheInfo: {
          age: cacheAge,
          valid: modelStatusCache.isValid(baseURL),
          totalCacheEntries: cacheStats.size
        },
        performanceHint: loadedModels.length > 1
          ? `Note: ${loadedModels.length} models loaded. Consider unloading unused models for better performance.`
          : cacheAge > 20000
          ? `Cache is ${Math.round(cacheAge/1000)}s old. Consider refreshing if model status seems outdated.`
          : undefined
      }
    }
  }
}