import { ModelStatusCache } from '../cache/model-status-cache'
import { ToastNotifier } from '../ui/toast-notifier'
import { categorizeModel, formatModelName, extractModelOwner } from '../utils'
import { normalizeBaseURL, checkProviderHealth, discoverModelsFromProvider, autoDetectOpenAICompatibleProvider } from '../utils/openai-compatible-api'
import { canDiscoverModels } from '../utils/validation'
import { getProviderFilter, getDiscoveryConfig, shouldDiscoverProvider } from '../types/plugin-config'
import type { PluginInput } from '@opencode-ai/plugin'
import type { OpenAIModel } from '../types'
import type { PluginConfig } from '../types/plugin-config'

const modelStatusCache = new ModelStatusCache()

interface DiscoveredProvider {
  name: string
  baseURL: string
  models: Record<string, any>
}

export async function enhanceConfig(
  config: any,
  client: PluginInput['client'],
  toastNotifier: ToastNotifier,
  pluginConfig: PluginConfig
): Promise<void> {
  modelStatusCache.invalidateAll()
  
  try {
    const providers = config.provider || {}
    const openAICompatibleProviders: DiscoveredProvider[] = []
    const providerFilter = getProviderFilter(pluginConfig)
    const discoveryConfig = getDiscoveryConfig(pluginConfig)

    for (const [providerName, providerConfig] of Object.entries(providers)) {
      const p = providerConfig as any
      
      if (!canDiscoverModels(p)) {
        continue
      }

      if (!shouldDiscoverProvider(providerName, providerFilter)) {
        console.log(`[opencode-model-discovery] Skipping provider '${providerName}' (filtered out)`)
        continue
      }

      let baseURL: string
      let displayName = providerName

      if (p.options?.baseURL) {
        baseURL = normalizeBaseURL(p.options.baseURL)
      } else {
        continue
      }

      const apiKey = p.options?.apiKey

      const isHealthy = await checkProviderHealth(baseURL, apiKey)
      if (!isHealthy) {
        console.warn(`[opencode-model-discovery] Provider '${providerName}' appears to be offline`, { baseURL })
        continue
      }

      let models: OpenAIModel[]
      try {
        models = await discoverModelsFromProvider(baseURL, apiKey)
      } catch (error) {
        console.warn(`[opencode-model-discovery] Model discovery failed for '${providerName}'`, {
          error: error instanceof Error ? error.message : String(error)
        })
        continue
      }

      if (models.length === 0) {
        console.warn(`[opencode-model-discovery] No models found for '${providerName}'`)
        continue
      }

      const existingModels = p.models || {}
      const discoveredModels: Record<string, any> = {}
      let chatModelsCount = 0
      let embeddingModelsCount = 0

      for (const model of models) {
        let modelKey = model.id
        if (!/^[a-zA-Z0-9_-]+$/.test(modelKey)) {
          modelKey = model.id.replace(/[^a-zA-Z0-9_-]/g, "_")
        }

        if (!existingModels[modelKey] && !existingModels[model.id]) {
          const modelType = categorizeModel(model.id)
          const owner = extractModelOwner(model.id)
          const modelConfig: any = {
            id: model.id,
            name: formatModelName(model),
          }

          if (owner) {
            modelConfig.organizationOwner = owner
          }

          if (modelType === 'embedding') {
            embeddingModelsCount++
            modelConfig.modalities = {
              input: ["text"],
              output: ["embedding"]
            }
          } else if (modelType === 'chat') {
            chatModelsCount++
            modelConfig.modalities = {
              input: ["text", "image"],
              output: ["text"]
            }
          }

          discoveredModels[modelKey] = modelConfig
        }
      }

      if (Object.keys(discoveredModels).length > 0) {
        p.models = {
          ...existingModels,
          ...discoveredModels,
        }

        openAICompatibleProviders.push({
          name: displayName,
          baseURL,
          models: discoveredModels
        })

        if (chatModelsCount === 0 && embeddingModelsCount > 0) {
          console.warn(`[opencode-model-discovery] Provider '${providerName}' only has embedding models:`, {
            steps: [
              "1. This provider has no chat models available",
              "2. Load a chat model in your provider application",
              "3. Restart the server",
              "4. The plugin will automatically discover it"
            ]
          })
        }
      }
    }

    if (openAICompatibleProviders.length > 0) {
      const totalModels = openAICompatibleProviders.reduce((sum, p) => sum + Object.keys(p.models).length, 0)
      console.log(`[opencode-model-discovery] Discovered ${totalModels} models across ${openAICompatibleProviders.length} provider(s)`)

      for (const p of openAICompatibleProviders) {
        console.log(`[opencode-model-discovery]   ${p.name}: ${Object.keys(p.models).length} models added`)
      }
    }

    if (Object.keys(providers).length === 0) {
      const detected = await autoDetectOpenAICompatibleProvider()
      if (detected) {
        console.log(`[opencode-model-discovery] Detected ${detected.name} at ${detected.baseURL}`)
        console.log(`[opencode-model-discovery] Add it to your config to enable model discovery`)
      }
    }

    try {
      for (const [providerName, providerConfig] of Object.entries(providers)) {
        const p = providerConfig as any
        if (!canDiscoverModels(p) || !shouldDiscoverProvider(providerName, providerFilter)) {
          continue
        }
        if (p.options?.baseURL) {
          const baseURL = normalizeBaseURL(p.options.baseURL)
          if (discoveryConfig.ttl) {
            modelStatusCache.setTTL(baseURL, discoveryConfig.ttl)
          }
          if (!modelStatusCache.isValid(baseURL)) {
            await modelStatusCache.getModels(baseURL, async () => {
              return await discoverModelsFromProvider(baseURL).then(models => models.map(m => m.id))
            })
          }
        }
      }
    } catch (error) {
    }
  } catch (error) {
    console.error("[opencode-model-discovery] Unexpected error in enhanceConfig:", error)
    toastNotifier.warning("Plugin configuration failed", "Configuration Error").catch(() => {})
  }
}